<?php

namespace App\Http\Controllers;

use App\Mail\OtpMail;
use App\Models\VoteResult;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;

class OtpController extends Controller
{

   
}
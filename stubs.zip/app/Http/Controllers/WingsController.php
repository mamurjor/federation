<?php

namespace App\Http\Controllers;

use Stripe\Charge;
use Session;
use Stripe\Stripe;
use App\Models\User;
use App\Models\Tehsil;
use App\Models\Country;
use App\Models\District;
use App\Models\Votetype;
use App\Models\WingsNomini;
use Illuminate\Support\Str;
use App\Mail\VerifyEmailOne;
use App\Mail\VerifyEmailTwo;
use Illuminate\Http\Request;
use App\Models\WingsVoteannounce;
use App\Models\VotingPositionType;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use App\Events\VoteAnnouncementPosted;
use App\Events\WingsVoteAnnouncementPosted;

class WingsController extends Controller
{

    public function wingsvoteannouncecreate(){
     
        $country          = Country::all();
        $district         = District::all();
        $tehsil           = Tehsil::all();
        $votetype         = Votetype::all();
        $votepositiontype = VotingPositionType::all();
        return view('frontend.pages.WingsVoteAnnounce.create',compact('votetype','country','district','tehsil','votepositiontype'));
    } 



    public function wingsvoteannouncestore(Request $request)
    {
              
        $position_type = serialize($request->votepositiontype);

        
                // $image      = $request->file('voteimage');
                // $imageName  = time() . '.' . $image->getClientOriginalExtension();
                // $path       = '/admin/vote/'.$imageName;
                // $image_path = $image->move(public_path('admin/vote'), $imageName);
        
        $request->validate([
    
            'type'             => 'required',
            'typeDetails'      => 'required',
            'profession'       => 'required',
            'announce'         => 'required',
            'date'             => 'required',
            'votetype'         => 'required',
            'votepositiontype' => 'required',
        ]);

        $voteannounceinfo = [
            'type'             => $request->type,
            'type_name'        => $request->typeDetails,
            'profession_name'  => $request->profession,
            'announce'         => $request->announce,
            'votetype'         => $request->votetype,
            'votingdate'       => $request->date,
            'votepositiontype' => $position_type,
        ];
    
        $saveinfo = WingsVoteannounce::create($voteannounceinfo);
                // event(new VoteAnnouncementPosted($saveinfo));
            event(new WingsVoteAnnouncementPosted($saveinfo));


                      //  dd($saveinfo);
        return redirect()->route('voteannounce.index')->with('success','Created successfully.');
    }


      public function wingsvoteannounceedit($id)

          {
              $votepositiontype               = VotingPositionType::all();
              $voteannounce                   = WingsVoteannounce::where('id', $id)->first();
              $votetype                       = Votetype::all();
              $voteannounce->votepositiontype = unserialize($voteannounce->votepositiontype);

              return view('frontend.pages.WingsVoteAnnounce.edit',compact('voteannounce','votepositiontype','votetype'));
          }


      public function wingsvoteannounceupdate(Request $request)
      {
    
    
          $voteannounce = WingsVoteannounce::find($request->id);

          $position_type = serialize($request->votepositiontype);


          $request->validate([
    
            'type'             => 'required',
            'typeDetails'      => 'required',
            'profession'       => 'required',
            'announce'         => 'required',
            'date'             => 'required',
            'votetype'         => 'required',
            'votepositiontype' => 'required',
        ]);
        
          if ($voteannounce) {
                          // Update the record
              $voteannounce->update([
                'type'             => $request->type,
                'type_name'        => $request->typeDetails,
                'profession_name'  => $request->profession,
                'announce'         => $request->announce,
                'votetype'         => $request->votetype,
                'votingdate'       => $request->date,
                'votepositiontype' => $position_type,
              ]);
    
              return redirect()->route('voteannounce.index')->with('success', 'Update Successful!');
          } 
          else {
              return redirect()->route('voteannounce.index')->with('error', 'Record not found!');
          }
      }


      public function wingsvoteannouncedelete(Request $request){

          $voteannounce = WingsVoteannounce::find($request->id);

          if ($voteannounce) {
        
              $voteannounce->delete();
          }

          return redirect()->route('voteannounce.index')->with('success','deleted successfully');
      }


    public function getNames(Request $request)
    {
        $modelName  = $request->input('model');
        $modelClass = 'App\\Models\\' . $modelName;

        if (class_exists($modelClass)) {
            $names = $modelClass::pluck('name');  // Adjust this to your column name
            return response()->json($names);
        } else {
            return response()->json(['error' => 'Model not found'], 404);
        }
    }

    public function getProfessions(Request $request)
    {
        $type  = $request->input('type');
        $value = $request->input('value');
        
        $users = User::where($type, $value)->pluck('profession');  // Adjust this to your user table's structure
        return response()->json($users);
    }


    public function wingsnominiform($id){
            // dd($id);
        $wingsvoteannouncement = WingsVoteannounce::where('id',$id)->first();
            // dd($wingsvoteannouncement);
        return view('frontend.pages.Nomination.wingsnominiform',compact('wingsvoteannouncement'));
    }

    public function wingsnoministore(Request $request){

        $request->validate([
          'emailone' => 'required',
          'emailtwo' => 'required',
          'position' => 'required',
        ]);
        
        $request->session()->put('votetype', $request->votetype);
        $request->session()->put('id', $request->id);
        $request->session()->put('type', $request->type);
        $request->session()->put('type_name', $request->type_name);
        $request->session()->put('profession_name', $request->profession_name);
        $request->session()->put('announce', $request->announce);
        $request->session()->put('date', $request->date);
        $request->session()->put('emailone', $request->emailone);
        $request->session()->put('emailtwo', $request->emailtwo);
        $request->session()->put('charge', $request->charge);
        $request->session()->put('position', $request->position);
        $request->session()->put('email_one_verified' , false);
        $request->session()->put('email_two_verified' , false);
          

        return redirect()->route('wingsstripe')->with('success','Please Payment $'.Session::get('charge'));

    }

    public function wingsstripe(){
        return view("frontend.pages.paymentform.wingspayment");
      }

    public function wingsstripestore(Request $request)
    {

      $tokenOne = Str::random(32);
      $tokenTwo = Str::random(32);

        Stripe::setApiKey(env('STRIPE_SECRET'));
    
        Charge::create ([
                "amount"      => Session::get('charge'),
                "currency"    => "usd",
                "source"      => $request->stripeToken,
                "description" => "Thanks for the payment."
        ]);
        
                  // Session::get('amount');
        Session::flash('success', 'Payment successful!');


       $nomini = WingsNomini::create([
            'wingsnomini_id'     => Auth::id(),
            'type'               => Session::get('type'),
            'type_name'          => Session::get('type_name'),
            'profession_name'    => Session::get('profession_name'),
            'announce'           => Session::get('announce'),
            'votetype'           => Session::get('votetype'),
            'votingdate'         => Session::get('date'),
            'emailone'           => Session::get('emailone'),
            'emailtwo'           => Session::get('emailtwo'),
            'charge'             => Session::get('charge'),
            'votepositiontype'   => Session::get('position'),
            'email_one_verified' => Session::get('email_one_verified'),
            'email_two_verified' => Session::get('email_two_verified'),
            'token_one'          => $tokenOne,
            'token_two'          => $tokenTwo,
            'card_number'        => $request->cardNumber,
            'stripe_token'       => 'see your stripe account',
            'payment_type'       => 'Stripe',
        ]);
                  // dd($nomini);
              Mail::to(Session::get('emailone'))->send(new VerifyEmailOne(Session::get('emailone'), $tokenOne));
              Mail::to(Session::get('emailtwo'))->send(new VerifyEmailTwo(Session::get('emailtwo'), $tokenTwo));
        
        return back();
    }

    public function approve(Request $request){

        $wingsnomini = WingsNomini::find($request->id);
        $wingsnomini->status = '1';
        $wingsnomini->save();
      
        return redirect()->back()->with('success', 'Nomination approved successfully.');
       }
       
      public function declined(Request $request){

        $wingsnomini = WingsNomini::find($request->id);
        $wingsnomini->status = '0';
        $wingsnomini->save();
      
        return redirect()->back()->with('success', 'Nomination declined successfully.');
       }

       public function wingsnominidelete(Request $request){
           
           $wingsnomini = WingsNomini::find($request->id);
           if ($wingsnomini) {
               $wingsnomini->delete();
            }
      
        return redirect()->back()->with('success','deleted successfully');
      }
}
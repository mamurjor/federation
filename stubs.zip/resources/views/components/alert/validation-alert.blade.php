@if (!empty($message))
<div class="alert alert-{{ $type }} mb-0">
    <strong>{{ $message }}</strong>
</div>
@endif


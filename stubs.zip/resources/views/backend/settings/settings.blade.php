@extends('backend.client')

@section('main-content')
<div class="row">
    <div class="col-xl">
        <div class="card m-3">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Settings</h5>
                
            </div>
         
        </div>
    </div>

</div>
@endsection

@extends('backend.dash')
@section('main-content')
    <div class="m-3">
        <h3>Paypal</h3>
        <h3>Stripe</h3>
    </div>
@endsection

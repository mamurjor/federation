
<?php $__env->startSection('title', 'Singlecast'); ?>
<?php $__env->startSection('content'); ?>

<main>
    <!-- breadcrumd section start -->
    <section id="breadcrumd_section" class="breadcrumd_section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="breadcrumd_heading text-center">
                        <h2 class="fw-bold">Rajput</h2>
                        <span><a href="#" class="text-black">Home</a> / <a href="#" class="text-black">Cast List</a> / Rajput</span>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumd section end -->
    <!-- Cast single section start -->
    <section id="cast_single_section" class="cast_single_section">
        <div class="container">
            
            <?php echo $singlecast->content; ?>

            
        </div>
    </section>
    <!-- Cast single section end -->
   </main>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kamrul\federation\resources\views/backend/cast/singlecast.blade.php ENDPATH**/ ?>
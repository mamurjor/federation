<?php $__env->startSection('title', 'hhhh'); ?>
<?php $__env->startSection('content'); ?>
    <main>
        <section id="login_registration_section" class="registration_section">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-7">
                        <div class="register_main_bg login_main_bg">
                            <div class="common_heading text-center">
                                <img src="./img/registration_page/res_logo.png" alt="">
                                <h2 class="fw-bold mb-3 mt-3 text-black">Login Now</h2>
                                <div class="row align-items-center mb-5">
                                    <div class="col-md-4"><img class="p_leftRight_image" src="./img/home_page/our_misson_section/rightimg.png" alt=""></div>
                                    <div class="col-md-4"><p class="fw-normal text-black">Start a new Journey With Us.</p></div>
                                    <div class="col-md-4"><img class="p_leftRight_image" src="./img/home_page/our_misson_section/leftiimg.png" alt=""></div>
                                </div>
                            </div>
                            <form action="<?php echo e(route('login')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <div class="form-group">
                                                <?php if (isset($component)) { $__componentOriginal731fbcf896864014c1db703fff52f950 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal731fbcf896864014c1db703fff52f950 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.textbox','data' => ['labelName' => 'Email Address','parantClass' => 'col-12 col-md-12','name' => 'email','type' => 'email','required' => 'required','placeholder' => 'Enter Email..!','errorName' => 'email','class' => 'py-3 fs-5','value' => ''.e(old('email') ?? '').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.textbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['labelName' => 'Email Address','parantClass' => 'col-12 col-md-12','name' => 'email','type' => 'email','required' => 'required','placeholder' => 'Enter Email..!','errorName' => 'email','class' => 'py-3 fs-5','value' => ''.e(old('email') ?? '').'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal731fbcf896864014c1db703fff52f950)): ?>
<?php $attributes = $__attributesOriginal731fbcf896864014c1db703fff52f950; ?>
<?php unset($__attributesOriginal731fbcf896864014c1db703fff52f950); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal731fbcf896864014c1db703fff52f950)): ?>
<?php $component = $__componentOriginal731fbcf896864014c1db703fff52f950; ?>
<?php unset($__componentOriginal731fbcf896864014c1db703fff52f950); ?>
<?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <div class="form-group">
                                                <?php if (isset($component)) { $__componentOriginal731fbcf896864014c1db703fff52f950 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal731fbcf896864014c1db703fff52f950 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.textbox','data' => ['labelName' => 'Password','parantClass' => 'col-12 col-md-12','name' => 'password','type' => 'password','required' => 'required','placeholder' => 'Enter Password..!','errorName' => 'password','class' => 'py-3 fs-5','value' => ''.e(old('password') ?? '').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.textbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['labelName' => 'Password','parantClass' => 'col-12 col-md-12','name' => 'password','type' => 'password','required' => 'required','placeholder' => 'Enter Password..!','errorName' => 'password','class' => 'py-3 fs-5','value' => ''.e(old('password') ?? '').'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal731fbcf896864014c1db703fff52f950)): ?>
<?php $attributes = $__attributesOriginal731fbcf896864014c1db703fff52f950; ?>
<?php unset($__attributesOriginal731fbcf896864014c1db703fff52f950); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal731fbcf896864014c1db703fff52f950)): ?>
<?php $component = $__componentOriginal731fbcf896864014c1db703fff52f950; ?>
<?php unset($__componentOriginal731fbcf896864014c1db703fff52f950); ?>
<?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <div class="form-group align-items-center">
                                                <input class="form-check-input p-3" type="checkbox" value="" id="flexCheckChecked">
                                                <label class="form-check-label pt-2" for="flexCheckChecked">
                                                    I hereby accept the <span>Terms and conditions</span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <button type="submit" class="btn btn-primary waves-effect waves-light">Login<i class="fa-solid fa-circle-plus ms-2"></i></button>
                                        </div>
                                    </div>
                                    
                                </div>
                            </form>
                            <div class="row align-items-center mb-3 mt-4">
                                <div class="col-md-4"><img class="p_leftRight_image" src="./img/registration_page/res_right.png" alt=""></div>
                                <div class="col-md-4"><p class="fw-normal text-danger text-center img_mid_text">Forgot Your Password?</p></div>
                                <div class="col-md-4"><img class="p_leftRight_image" src="./img/registration_page/res_left.png" alt=""></div>
                            </div>
                            <h6 class="text-center have_account">Reset your password?<a href="<?php echo e(route('password.request')); ?>" class="text-danger"> Reset</a></h6>
                        </div>
                        
                    </div>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kamrul\federation\resources\views/auth/login.blade.php ENDPATH**/ ?>
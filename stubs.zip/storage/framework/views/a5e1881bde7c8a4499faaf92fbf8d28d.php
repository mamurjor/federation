

<?php $__env->startSection('main-content'); ?>
    <div class="card m-3">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5>Mission Section List</h5>
            <h5><a class="btn btn-primary waves-effect waves-light" href="<?php echo e(route('missionsection.create')); ?>"> Add New </a></h5>
        </div>
        <div class="table-responsive text-nowrap">
            <table class="table">
                <thead>
                    <tr>
                        <th>SL No. </th>
                        <th>Title</th>
                        
                        <th>Image </th>
                        <th>Action </th>

                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    <?php $__currentLoopData = $MissionSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $singlevalue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>

                                <span class="fw-medium ms-2"><?php echo e($index + 1); ?></span>
                            </td>
                            <td><?php echo e($singlevalue->title); ?></td>

                            
                            <td>
                                <img width="100" height="100" src=" <?php echo url('/') . $singlevalue['imageurl']; ?>" alt="tst">
                            </td>

                            <td>
                                <div class="dropdown">
                                    <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                        data-bs-toggle="dropdown">
                                        <i class="ti ti-dots-vertical"></i>
                                    </button>

                                    <a class="btn btn-primary" href="<?php echo e(route('missionsection.edit', $singlevalue->id)); ?>"><i
                                            class="ti ti-pencil me-2"></i> Edit</a>
                                    <a class="btn btn-danger" href="<?php echo e(route('missionsection.delete', $singlevalue->id)); ?>"
                                        onclick="return confirm('Are Your Suere')"> Delete</a>

                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kamrul\federation\resources\views/backend/page/missionsection/index.blade.php ENDPATH**/ ?>
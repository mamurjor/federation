<!-- our mission start -->
<section id="our_mission" class="our_mission">
    <div class="container">
        <div class="row">

            <?php

                $data = json_decode($MissionSections, true);

            ?>

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singlevalue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-md-12">
                <div class="common_heading text-center">
                     <img src=" <?php echo url('/').$singlevalue['imageurl'];?>" alt="<?php echo e($singlevalue['title']); ?>">
                   
                        
                    <h2 class="fw-bold mb-5 mt-5 text-white"> <?php echo e($singlevalue['title']); ?></h2>
                    <div class="row align-items-center">
                        <div class="col-md-3">
                            <img class="p_leftRight_image"
                                src="<?php echo e(asset('frontend/assets/img/home_page/our_misson_section/rightimg.png')); ?>"
                                alt=""> 
                               
                            </div>
                        <div class="col-md-6">
                            <p class="fw-normal text-white"><?php echo e($singlevalue['slogan']); ?></p>
                        </div>
                        <div class="col-md-3">
                            <img class="p_leftRight_image"
                                src="<?php echo e(asset('frontend/assets/img/home_page/our_misson_section/leftimg.png')); ?>"
                                alt=""> 
                               
                            </div>
                    </div>
                    <h5 class="text-left text-white mt-5"><?php echo e($singlevalue['description']); ?></h5>

                    <div class="carousel_btn_div our_mission_button_main">
                        <div class="common_button carosel_button1">
                            <a target="_blank" href="<?php echo e($singlevalue['button_one_url']); ?>"><?php echo e($singlevalue['button_one_text']); ?><i class="fa-solid fa-arrow-right ms-2"></i></a>
                        </div>
                        <div class="common_button">
                            <a href="<?php echo e($singlevalue['button_two_url']); ?>" target="_blank"><?php echo e($singlevalue['button_two_text']); ?><i class="fa-solid fa-circle-plus ms-2"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


           
        </div>
    </div>
</section>
<?php /**PATH D:\kamrul\federation\resources\views/frontend/pages/home/our_mission.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title', 'cast'); ?>
<?php $__env->startSection('content'); ?>


    <main>
        <!-- breadcrumd section start -->
        <section id="breadcrumd_section" class="breadcrumd_section">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="breadcrumd_heading text-center">
                            <h2 class="fw-bold">Cast List</h2>
                            <span><a href="#" class="text-black">Home</a> / Cast List</span>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- breadcrumd section end -->
        <!-- member list section start -->
        <section id="member_list_section" class="member_list_section">
            <div class="container">
                <div class="row">

                    <?php $__currentLoopData = $castpost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 col-sm-6 col-lg-4 col-xl-2 mb-4">
                            <div class="latest_member_box cast_boxs text-center">
                                <img class="mb-3" src="<?php echo e($cast->image); ?>" alt="">
                                <h6 class="mb-2"><?php echo e($cast->name); ?></h6>
                                <a href="<?php echo e(route('cast.single', $cast->id)); ?>">Read More</a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </section>
        <!-- member list section end -->
    </main>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kamrul\federation\resources\views/backend/cast/cast.blade.php ENDPATH**/ ?>
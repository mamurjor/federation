
<?php $__env->startSection('main-content'); ?>
    <style>
        .member_heading {
            text-align: center;
        }

        .member_heading h4 {
            font-size: 16px;
            line-height: 26px;
            color: #000;
            font-weight: 600;
            margin-bottom: 0;
        }

        .member_heading p {
            font-size: 14px;
            line-height: 20px;
            color: #7855F0;
            margin-bottom: 10px;
        }

        .member_img img {
            width: 100%;
        }

        .member_heading {
            position: absolute;
            background: white;
            padding: 20px;
            margin-top: -50px;
            z-index: 999;
            left: 50%;
            transform: translateX(-50%);
            width: 200px;
            border-radius: 15px;
            box-shadow: 0 0 38px 0 #0b223915;
        }

        .latest_member_box {
            padding: 10px 10px 90px 10px;
            background: white;
            border-radius: 5px;
            box-shadow: 0 0 38px 0 #0b223915;
            border: 1px solid white;
            transition: .6s;
        }

        .latest_member_box:hover {
            border-color: #7855F0;
        }

        .otp_heading h5 {
            font-size: 16px;
            line-height: 20px;
            color: #000;
            margin-bottom: 0;
        }

        .otp_heading p {
            font-size: 14px;
            line-height: 20px;
            color: #8e8989;
            margin-bottom: 0;
            margin-top: 4px;
        }

        .otp_icon i {
            background: #ff00001c;
            padding: 12px;
            border-radius: 5px;
            font-size: 21px;
        }
    </style>
    
    

    

    <div class="row">
        <?php $__currentLoopData = $wingsnomini_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nomini): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 mt-3">
                <div class="latest_member_box position-relative">
                    <div class="member_img">
                        <?php if($nomini->user): ?>
                            <img src="<?php echo e($nomini->user->userimage); ?>" alt="">
                        <?php endif; ?>
                        <div class="member_heading">
                            <?php if($nomini->user): ?>
                                <h4><?php echo e($nomini->user->fname); ?></h4>
                            <?php endif; ?>
                            <p><?php echo e($nomini->votepositiontype); ?></p>
                            <button class="btn btn-sm btn-primary vote-btn" data-bs-toggle="modal"
                                data-bs-target="#otpModal"
                                data-nomini-id="<?php echo e($nomini->id); ?>"
                                data-email="<?php echo e($nomini->user->email); ?>"
                                data-votepositiontype="<?php echo e($nomini->votepositiontype); ?>"
                                data-votetype="<?php echo e($nomini->votetype); ?>"
                                data-votingdate="<?php echo e($nomini->votingdate); ?>"
                                data-type="<?php echo e($nomini->type); ?>"
                                data-type_name="<?php echo e($nomini->type_name); ?>"
                                data-profession_name="<?php echo e($nomini->profession_name); ?>"
                                >Vote Now<i class="fa-solid fa-circle-plus ms-1"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<!-- OTP Modal -->
<?php echo $__env->make('backend.applymodal.apply', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

<script>
    $(document).ready(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('.vote-btn').on('click', function() {
            var nominiId = $(this).data('nomini-id');
            var email = $(this).data('email');
            var votepositiontype = $(this).data('votepositiontype');
            var votetype = $(this).data('votetype');
            var votingdate = $(this).data('votingdate');
            var type = $(this).data('type');
            var type_name = $(this).data('type_name');
            var profession_name = $(this).data('profession_name');

            $.ajax({
                url: '<?php echo e(route('send.otp')); ?>',
                method: 'POST',
                data: {
                    nomini_id: nominiId,
                    email: email
                },
                success: function(response) {
                    // console.log('Response:', response);
                    if (response.success) {
                        $('#otpModal').modal('show');
                        $('#hidden_nomini_id').val(nominiId);
                        $('#otpForm').data({
                            votepositiontype: votepositiontype,
                            votetype: votetype,
                            votingdate: votingdate,
                            type: type,
                            type_name: type_name,
                            profession_name: profession_name
                        });
                    } else {
                        alert('Failed to send OTP. Please try again. ' + response.message);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error:', error);
                    alert('Failed to send OTP. Please try again.');
                }
            });
        });

        $('#otpForm').on('submit', function(e) {
            e.preventDefault();

            var otp = $('#otp').val();
            var nominiId = $('#hidden_nomini_id').val();
            var data = $(this).data();

            $.ajax({
                url: '<?php echo e(route('verify.otp')); ?>',
                method: 'POST',
                data: {
                    otp: otp,
                    nomini_id: nominiId
                },
                success: function(response) {
                    // console.log('Verify OTP Response:', response);
                    if (response.success) {
                        // alert('OTP verified successfully!');
                        // Submit the data to store
                        $.ajax({
                            url: '<?php echo e(route('store.wingsvote.data')); ?>',
                            method: 'POST',
                            data: {
                                _token: '<?php echo e(csrf_token()); ?>',
                                nomini_id: nominiId,
                                votepositiontype: data.votepositiontype,
                                votetype: data.votetype,
                                votingdate: data.votingdate,
                                type: data.type,
                                type_name: data.type_name,
                                profession_name: data.profession_name,
                                user_id: '<?php echo e(Auth::id()); ?>' // Add the user_id here
                            },
                            success: function(storeResponse) {
                                // console.log('Store Vote Data Response:', storeResponse);
                                if (storeResponse.success) {
                                    // alert('Vote cast successfully!');

                                    $('#otpModal').modal('hide');
                                    $('#voteSuccess').modal('show');
                                } else {
                                    alert(
                                        'Failed to cast vote. Please try again.'
                                    );
                                }
                            },
                            error: function(xhr, status, error) {
                                console.error('Store Vote Data Error:', error);
                                alert('Failed to cast vote. Please try again.');
                            }
                        });

                    } else {
                        // alert('Invalid OTP. Please try again.');
                        $('#voteFailed').modal('show');

                    }
                },
                error: function(xhr, status, error) {
                    console.error('Verify OTP Error:', error);
                    alert('Failed to verify OTP. Please try again.');
                }
            });
        });
    });
</script>

<?php echo $__env->make('backend.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kamrul\federation\resources\views/frontend/pages/votedetails/wingsvotedetails.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>OTP Code</title>
</head>
<body>
    <h1>Your OTP Code</h1>
    <p>Your OTP code is: <?php echo e($otp); ?></p>
</body>
</html>
<?php /**PATH D:\kamrul\federation\resources\views/emails/otp.blade.php ENDPATH**/ ?>
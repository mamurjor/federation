
<div class="u-row-container" style="padding: 0px;background-color: transparent">
    <div class="u-row"
        style="Margin: 0 auto;min-width: 320px;max-width: 600px;overflow-wrap: break-word;word-wrap: break-word;word-break: break-word;background-color: #e5eaf5;">
        <div
            style="border-collapse: collapse;display: table;width: 100%;height: 100%;background-color: transparent;">
            <!--[if (mso)|(IE)]><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="padding: 0px;background-color: transparent;" align="center"><table cellpadding="0" cellspacing="0" border="0" style="width:600px;"><tr style="background-color: #e5eaf5;"><![endif]-->

            <!--[if (mso)|(IE)]><td align="center" width="600" style="width: 600px;padding: 0px;border-top: 0px solid transparent;border-left: 0px solid transparent;border-right: 0px solid transparent;border-bottom: 0px solid transparent;" valign="top"><![endif]-->
            <div class="u-col u-col-100"
                style="max-width: 320px;min-width: 600px;display: table-cell;vertical-align: top;">
                <div style="height: 100%;width: 100% !important;">
                    <!--[if (!mso)&(!IE)]><!-->
                    <div
                        style="padding: 0px;border-top: 0px solid transparent;border-left: 0px solid transparent;border-right: 0px solid transparent;border-bottom: 0px solid transparent;">
                        <!--<![endif]-->

                        <table style="font-family:'Cabin',sans-serif;" role="presentation"
                            cellpadding="0" cellspacing="0" width="100%" border="0">
                            <tbody>
                                <tr>
                                    <td style="overflow-wrap:break-word;word-break:break-word;padding:41px 55px 18px;font-family:'Cabin',sans-serif;"
                                        align="left">

                                        <div
                                            style="color: #003399; line-height: 160%; text-align: center; word-wrap: break-word;">
                                            <p style="font-size: 14px; line-height: 160%;"><span
                                                    style="font-size: 18px; line-height: 28.8px;"><strong><span
                                                            style="line-height: 28.8px; font-size: 18px;"><span
                                                                style="line-height: 28.8px; font-size: 18px;"><span
                                                                    style="line-height: 28.8px; font-size: 18px;">Get
                                                                    in
                                                                    Touch</span></span></span></strong></span>
                                            </p>
                                            <p style="font-size: 14px; line-height: 160%;"><span
                                                    style="font-size: 16px; line-height: 25.6px; color: #000000;">+885494507987</span></p>
                                            <p style="font-size: 14px; line-height: 160%;"><span
                                                    style="font-size: 16px; line-height: 25.6px;">pigeondex@gmail.com</span>
                                            </p>
                                        </div>

                                    </td>
                                </tr>
                            </tbody>
                        </table>

                        <table style="font-family:'Cabin',sans-serif;" role="presentation"
                            cellpadding="0" cellspacing="0" width="100%" border="0">
                            <tbody>
                                <tr>
                                    <td style="overflow-wrap:break-word;word-break:break-word;padding:10px 10px 33px;font-family:'Cabin',sans-serif;"
                                        align="left">

                                        <div align="center">
                                            <div style="display: table; max-width:244px;">
                                                <table align="left" border="0" cellspacing="0"
                                                    cellpadding="0" width="32" height="32"
                                                    style="width: 32px !important;height: 32px !important;display: inline-block;border-collapse: collapse;table-layout: fixed;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;vertical-align: top;margin-right: 17px">
                                                    <tbody>
                                                        <tr style="vertical-align: top">
                                                            <td align="left" valign="middle"
                                                                style="word-break: break-word;border-collapse: collapse !important;vertical-align: top">
                                                                <a href="https://www.facebook.com/"
                                                                    title="Facebook"
                                                                    target="_blank">
                                                                    <img src="https://doppcall.com/media/media-post/facebook-rounded-colored_383.png"
                                                                        alt="Facebook"
                                                                        title="Facebook" width="32"
                                                                        style="outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;clear: both;display: block !important;border: none;height: auto;float: none;max-width: 32px !important">
                                                                </a>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <table align="left" border="0" cellspacing="0"
                                                    cellpadding="0" width="32" height="32"
                                                    style="width: 32px !important;height: 32px !important;display: inline-block;border-collapse: collapse;table-layout: fixed;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;vertical-align: top;margin-right: 17px">
                                                    <tbody>
                                                        <tr style="vertical-align: top">
                                                            <td align="left" valign="middle"
                                                                style="word-break: break-word;border-collapse: collapse !important;vertical-align: top">
                                                                <a href="https://www.linkedin.com/"
                                                                    title="LinkedIn"
                                                                    target="_blank">
                                                                    <img src="https://doppcall.com/media/media-post/linkedin-rounded-colored_212.png"
                                                                        alt="LinkedIn"
                                                                        title="LinkedIn" width="32"
                                                                        style="outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;clear: both;display: block !important;border: none;height: auto;float: none;max-width: 32px !important">
                                                                </a>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <table align="left" border="0" cellspacing="0"
                                                    cellpadding="0" width="32" height="32"
                                                    style="width: 32px !important;height: 32px !important;display: inline-block;border-collapse: collapse;table-layout: fixed;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;vertical-align: top;margin-right: 17px">
                                                    <tbody>
                                                        <tr style="vertical-align: top">
                                                            <td align="left" valign="middle"
                                                                style="word-break: break-word;border-collapse: collapse !important;vertical-align: top">
                                                                <a href="https://www.instagram.com/"
                                                                    title="Instagram"
                                                                    target="_blank">
                                                                    <img src="https://doppcall.com/media/media-post/instagram_410.png"
                                                                        alt="Instagram"
                                                                        title="Instagram" width="32"
                                                                        style="outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;clear: both;display: block !important;border: none;height: auto;float: none;max-width: 32px !important">
                                                                </a>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <table align="left" border="0" cellspacing="0"
                                                    cellpadding="0" width="32" height="32"
                                                    style="width: 32px !important;height: 32px !important;display: inline-block;border-collapse: collapse;table-layout: fixed;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;vertical-align: top;margin-right: 17px">
                                                    <tbody>
                                                        <tr style="vertical-align: top">
                                                            <td align="left" valign="middle"
                                                                style="word-break: break-word;border-collapse: collapse !important;vertical-align: top">
                                                                <a href="https://twitter.com/"
                                                                    title="Twitter" target="_blank">
                                                                    <img src="https://doppcall.com/media/media-post/twitter-rounded-colored_987.png"
                                                                        alt="Twitter"
                                                                        title="Twitter" width="32"
                                                                        style="outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;clear: both;display: block !important;border: none;height: auto;float: none;max-width: 32px !important">
                                                                </a>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>

                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="u-row-container" style="padding: 0px;background-color: transparent">
    <div class="u-row"
        style="Margin: 0 auto;min-width: 320px;max-width: 600px;overflow-wrap: break-word;word-wrap: break-word;word-break: break-word;background-color: #1A76D1;">
        <div
            style="border-collapse: collapse;display: table;width: 100%;height: 100%;background-color: transparent;">
            <div class="u-col u-col-100"
                style="max-width: 320px;min-width: 600px;display: table-cell;vertical-align: top;">
                <div style="height: 100%;width: 100% !important;">
                    <div
                        style="padding: 0px;border-top: 0px solid transparent;border-left: 0px solid transparent;border-right: 0px solid transparent;border-bottom: 0px solid transparent;">

                        <table style="font-family:'Cabin',sans-serif;" role="presentation"
                            cellpadding="0" cellspacing="0" width="100%" border="0">
                            <tbody>
                                <tr>
                                    <td style="overflow-wrap:break-word;word-break:break-word;padding:10px;font-family:'Cabin',sans-serif;"
                                        align="left">

                                        <div
                                            style="color: #ffffff; line-height: 180%; text-align: center; word-wrap: break-word;">
                                            <p style="font-size: 14px; line-height: 180%;"><span
                                                    style="font-size: 16px; line-height: 28.8px; color: #fff">Copyrights
                                                    © PigeonDex  All Rights Reserved.</span></p>
                                        </div>

                                    </td>
                                </tr>
                            </tbody>
                        </table>

                        <!--[if (!mso)&(!IE)]><!-->
                    </div>
                    <!--<![endif]-->
                </div>
            </div>
            <!--[if (mso)|(IE)]></td><![endif]-->
            <!--[if (mso)|(IE)]></tr></table></td></tr></table><![endif]-->
        </div>
    </div>
</div>



<?php /**PATH D:\kamrul\federation\resources\views/mail/layouts/footer.blade.php ENDPATH**/ ?>
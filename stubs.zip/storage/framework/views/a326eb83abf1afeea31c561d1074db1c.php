<?php $__env->startSection('heading', $data['heading']); ?>
<?php $__env->startSection('content'); ?>
<tr>
    <td align="left" style="padding-bottom:20px;Margin:0">
        <table style="font-family:'Cabin',sans-serif;" role="presentation" cellpadding="0" cellspacing="0" width="100%" border="0">
            <tbody>
                <tr>
                    <td style="overflow-wrap:break-word;word-break:break-word;padding-right:55px;padding-left:55px;padding-bottom: 30px; font-family:'Cabin',sans-serif;" align="left">
                       <?php echo $data['body']; ?>

                    </td>
                </tr>
            </tbody>
        </table>
    </td>
</tr>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('mail.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kamrul\federation\resources\views/mail/verify.blade.php ENDPATH**/ ?>
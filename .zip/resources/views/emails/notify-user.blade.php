<!DOCTYPE html>
<html>
<head>
    <title>Email Verification Notification</title>
</head>
<body>
    <h1>Email Verification Notification</h1>
    <p>Dear {{ $user->fname }} {{ $emailMessage }}.</p>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
    <title>OTP Code</title>
</head>
<body>
    <h1>Your OTP Code</h1>
    <p>Your OTP code is: {{ $otp }}</p>
</body>
</html>

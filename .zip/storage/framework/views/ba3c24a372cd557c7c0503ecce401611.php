

<?php $__env->startSection('main-content'); ?>
    <div class="card m-3 ">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5>Wings List</h5>
            <h5><a class="btn btn-primary waves-effect waves-light" href="<?php echo e(route('wings.create')); ?>"> Add New </a></h5>
        </div>
        <table class="table-responsive table table-bordered" >
            <thead>
                <tr>
                    <th>SL No. </th>
                    <th>Wings Type</th>
                    <th>Wings Type Name</th>
                    <th>Profession Name</th>
                    <th>Action </th>

                </tr>
            </thead>
            <tbody class="table-border-bottom-0">
                <?php $__currentLoopData = $wings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $singlevalue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>

                            <span class="fw-medium ms-2"><?php echo e($index + 1); ?></span>
                        </td>
                        <td><?php echo e($singlevalue->wings_type); ?></td>
                        <td><?php echo e($singlevalue->wings_type_name); ?></td>

                        <td><span class="badge bg-label-success me-1"><?php echo e($singlevalue->profession_name); ?></span></td>
                        <td>
                            <div class="dropdown">
                                <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                    data-bs-toggle="dropdown">
                                    <i class="ti ti-dots-vertical"></i>
                                </button>

                                <a class="btn btn-primary" href="<?php echo e(route('wings.edit', $singlevalue->id)); ?>"><i
                                        class="ti ti-pencil me-2"></i> Edit</a>
                                <a class="btn btn-danger" href="<?php echo e(route('wings.delete', $singlevalue->id)); ?>"
                                    onclick="return confirm('Are Your Suere')"> Delete</a>

                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    

    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <div class="card my-5 mx-3">

        <div class="card-header font-weight-bold">
            <h2 class="float-left">Import Excel</h2>
        </div>

        <div class="card-body">

            <form id="excel-csv-import-form" method="POST" action="<?php echo e(url('import-excel-csv-file-Division')); ?>"
                accept-charset="utf-8" enctype="multipart/form-data">

                <?php echo csrf_field(); ?>

                <div class="row">

                    <div class="col-md-12">
                        <div class="form-group my-2">
                            <input class="form-control" type="file" name="file" placeholder="Choose file">
                        </div>
                        <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-md-12">
                        <button type="submit" class="btn btn-primary" id="submit">Submit</button>
                    </div>
                </div>
            </form>

        </div>

    </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kamrul\federation\resources\views/backend/page/wings/index.blade.php ENDPATH**/ ?>
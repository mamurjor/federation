<!DOCTYPE html>
<html>
<head>
    <title>Email Verification Notification</title>
</head>
<body>
    <h1>Email Verification Notification</h1>
    <p>Dear <?php echo e($user->fname); ?> <?php echo e($emailMessage); ?>.</p>
</body>
</html>
<?php /**PATH D:\kamrul\federation\resources\views/emails/notify-user.blade.php ENDPATH**/ ?>
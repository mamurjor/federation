

<?php $__env->startSection('main-content'); ?>
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5>Tehsil Vote announce List</h5>
            <h5><a class="btn btn-success waves-effect waves-light" href="<?php echo e(route('voteannounce.create')); ?>"> Add New </a>
            </h5>
        </div>
        <div class="table-responsive text-nowrap">
            <table class="table">
                <thead>
                    <tr>
                        <th>SL No. </th>
                        <th>votetype</th>
                        <th>position</th>
                        <th>Action </th>

                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">



                    <?php $__currentLoopData = $voteannounce; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $singlevalue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>

                                <span class="fw-medium ms-2"><?php echo e($index + 1); ?></span>
                            </td>
                            <td><?php echo e($singlevalue->votetype); ?></td>

                            <td>


                                <?php
                                    $positionlist = unserialize($singlevalue->votepositiontype);
                                ?>

                                <?php $__currentLoopData = $positionlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type='radio' class="childChk" value="<?php echo e($position); ?>" checked readonly/>
                                    <?php echo e($position); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </td>
                            <td>
                                <div class="dropdown">
                                    <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                        data-bs-toggle="dropdown">
                                        <i class="ti ti-dots-vertical"></i>
                                    </button>

                                    <a class="btn btn-primary" href="<?php echo e(route('voteannounce.edit', $singlevalue->id)); ?>"><i
                                            class="ti ti-pencil me-2"></i> Edit</a>
                                    <a class="btn btn-danger" href="<?php echo e(route('voteannounce.delete', $singlevalue->id)); ?>"
                                        onclick="return confirm('Are Your Suere')"> Delete</a>

                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>


    <div class="card mt-5">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5>Wings Vote announce List</h5>
            <h5><a class="btn btn-warning waves-effect waves-light" href="<?php echo e(route('wingsvoteannounce.create')); ?>"> Add New </a>
            </h5>
        </div>
        <div class="table-responsive text-nowrap">
            <table class="table">
                <thead>
                    <tr>
                        <th>SL No. </th>
                        <th>votetype</th>
                        <th>position</th>
                        <th>Action </th>

                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">



                    <?php $__currentLoopData = $voteannounce; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $singlevalue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>

                                <span class="fw-medium ms-2"><?php echo e($index + 1); ?></span>
                            </td>
                            <td><?php echo e($singlevalue->votetype); ?></td>

                            <td>


                                <?php
                                    $positionlist = unserialize($singlevalue->votepositiontype);
                                ?>

                                <?php $__currentLoopData = $positionlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type='radio' readonly class="childChk" value="<?php echo e($position); ?>" checked/>
                                    <?php echo e($position); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </td>
                            <td>
                                <div class="dropdown">
                                    <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                        data-bs-toggle="dropdown">
                                        <i class="ti ti-dots-vertical"></i>
                                    </button>

                                    <a class="btn btn-primary" href="<?php echo e(route('wingsvoteannounce.edit', $singlevalue->id)); ?>"><i
                                            class="ti ti-pencil me-2"></i> Edit</a>
                                    <a class="btn btn-danger" href="<?php echo e(route('wingsvoteannounce.delete', $singlevalue->id)); ?>"
                                        onclick="return confirm('Are Your Suere')"> Delete</a>

                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kamrul\federation\resources\views/frontend/pages/voteannounce/index.blade.php ENDPATH**/ ?>
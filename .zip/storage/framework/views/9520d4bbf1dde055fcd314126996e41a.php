

<?php $__env->startSection('main-content'); ?>
    <div class="row">
        <div class="col-xl">
            <div class="card m-3">

                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Update user information</h5>
                </div>

                <div class="card-body">

                    <?php if(Session::has('success')): ?>
                        <div class="text-success fw-bold my-2 text-center">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                            <p><?php echo e(Session::get('success')); ?></p>
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('user.register.update')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <div class="form-group">
                                        <label for="form-label" class="form-label">First Name <span
                                                class="text-danger">*</span></label>
                                        <input type="text" value="<?php echo e($user->fname); ?>" name="fname"
                                            class="form-control py-3 input_color" placeholder="Write your First name">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <div class="form-group">
                                        <label for="form-label" class="form-label">Middle Name <span
                                                class="text-danger">*</span></label>
                                        <input type="text" value="<?php echo e($user->mname); ?>" name="mname"
                                            class="form-control py-3 input_color" placeholder="Write your Middle Name">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <div class="form-group">
                                        <label for="form-label" class="form-label">Last Name <span
                                                class="text-danger">*</span></label>
                                        <input type="text" value="<?php echo e($user->lname); ?>" name="lname"
                                            class="form-control py-3 input_color" placeholder="Write your last name">
                                    </div>
                                </div>
                            </div>
                            
                            
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <div class="form-group">
                                        <label for="form-label" class="form-label">Select CAST <span
                                                class="text-danger">*</span></label>
                                        <select name="cast" id="country_residence" class="form-control input_color py-3">
                                            <option value="<?php echo e($user->cast); ?>" selected><?php echo e($user->cast); ?></option>

                                            <?php $__currentLoopData = $cast; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $singlevalue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($singlevalue->name); ?>"> <?php echo e($singlevalue->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <div class="mb-3">
                                    <div class="form-group">
                                        <label for="form-label" class="form-label">Your Profession <span
                                                class="text-danger">*</span></label>
                                        <select name="profession" id="your_profession"
                                            class="form-control input_color py-3">
                                            <option value="<?php echo e($user->profession); ?>" selected><?php echo e($user->profession); ?>

                                            </option>
                                            <?php $__currentLoopData = $professions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $singlevalue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($singlevalue->name); ?>"> <?php echo e($singlevalue->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="mb-3">
                                    <div class="form-group">
                                        <label for="form-label" class="form-label">Country Of Residence <span
                                                class="text-danger">*</span></label>
                                        <select name="country_residence" id="country_residence"
                                            class="form-control input_color py-3">
                                            <option value="<?php echo e($user->country); ?>" selected>
                                                <?php echo e($user->country); ?></option>
                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $singlevalue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($singlevalue->name); ?>"> <?php echo e($singlevalue->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <div class="form-group">
                                        <label for="form-label" class="form-label">Address Line 1 <span
                                                class="text-danger">*</span></label>
                                        <input type="text" value="<?php echo e($user->address_one); ?>" name="address_one"
                                            class="form-control py-3 input_color" placeholder="Address Line 1">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <div class="form-group">
                                        <label for="form-label" class="form-label">Address Line 2 <span
                                                class="text-danger">*</span></label>
                                        <input type="text" value="<?php echo e($user->address_two); ?>" name="address_two"
                                            class="form-control py-3 input_color" placeholder="Address Line 2">
                                    </div>
                                </div>
                            </div>

                            

                
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <div class="form-group">
                                        <label for="field1">Facebook Url</label>
                                        <input type="text" value="<?php echo e($user->facebook_url); ?>" class="form-control"
                                            id="icon" name="facebook_url">
                                    </div>
                                </div>
                            </div>
                   
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <div class="form-group">
                                        <label for="field1">Twitter Url</label>
                                        <input type="text" value="<?php echo e($user->twitter_url); ?>" class="form-control"
                                            id="icon" name="twitter_url">
                                    </div>
                                </div>
                            </div>
              
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <div class="form-group">
                                        <label for="field1">LinkedIn Url</label>
                                        <input type="text" value="<?php echo e($user->linkedin_url); ?>" class="form-control"
                                            id="icon" name="linkedin_url">
                                    </div>
                                </div>
                            </div>
                   
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <div class="form-group">
                                        <label for="field1">Youtube Url</label>
                                        <input type="text" value="<?php echo e($user->youtube_url); ?>" class="form-control"
                                            id="icon" name="youtube_url">
                                    </div>
                                </div>
                            </div>

                            

                            <div class="col-md-12">
                                <div class="mb-3">
                                    <div class="form-group">
                                        <label for="form-label" class="form-label">Short Bio <span
                                                class="text-danger">*</span></label>
                                        <textarea class="form-control py-3 input_color" name="short_bio" id="" cols="20" rows="2"><?php echo e($user->short_bio); ?></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="mb-3">
                                    <div class="form-group">
                                        <label for="form-label" class="form-label">Bio. <span
                                                class="text-danger">*</span></label>
                                        <textarea name="bio" id="summernote"><?php echo e($user->bio); ?></textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="mb-3">
                                    <div class="form-group">
                                        <label for="form-label" class="form-label">Your City <span
                                                class="text-danger">*</span></label>
                                        <input type="text" value="<?php echo e($user->city); ?>" name="your_city"
                                            class="form-control py-3 input_color" placeholder="Your City">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="mb-3">
                                    <div class="form-group">
                                        <label for="form-label" class="form-label">Phone No <span
                                                class="text-danger">*</span></label>
                                        <input type="text" value="<?php echo e($user->phone); ?>" name="phone"
                                            class="form-control py-3 input_color" placeholder="Phone No">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="mb-3">
                                    <div class="form-group">
                                        <label for="form-label" class="form-label">Email <span
                                                class="text-danger">*</span></label>
                                        <input type="text" value="<?php echo e($user->email); ?>" name="email"
                                            class="form-control py-3 input_color" placeholder="Write your Email">
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <div>
                                            <label for="form-label" class="form-label"> User Image Upload <span
                                                    class="text-danger">*</span></label>
                                            
                                            <input type="file" name="userimage"
                                                class="form-control py-3 mt-3 input_color"
                                                placeholder="Enter button Two url">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <img height="150" width="150" src="<?php echo e($user->userimage); ?>" alt="tst">
                                    </div>
                                </div>


                                <div class="col-md-12 ">
                                    <div class="mt-3 text-end">
                                        <button type="submit"
                                            class="py-4 mt-3 w-100 border-0 resgiter_button rounded">Update Information<i
                                                class="fa-solid fa-circle-plus ms-2"></i></button>
                                    </div>
                                </div>

                            </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('summerNote'); ?>
    <script>
        $('#summernote').summernote({
            placeholder: 'Enter bio...',
            tabsize: 2,
            height: 120,
            toolbar: [
                ['style', ['style']],
                ['font', ['bold', 'underline', 'clear']],
                ['color', ['color']],
                ['para', ['ul', 'ol', 'paragraph']],
                ['table', ['table']],
                ['insert', ['link', 'picture', 'video']],
                ['view', ['fullscreen', 'codeview', 'help']]
            ]
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kamrul\federation\resources\views/auth/user-update.blade.php ENDPATH**/ ?>
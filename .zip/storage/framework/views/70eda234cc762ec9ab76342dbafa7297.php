

<?php $__env->startSection('main-content'); ?>
    <div class="row">
        <div class="col-xl">
            <div class="card m-3">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5>Add Wings</h5>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('wings.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-12">

                                <div class="mb-6">
                                    <div class="form-group">
                                        <label for="form-label" class="form-label">Wings type<span
                                                class="text-danger">*</span></label>
                                        <select name="wings_type" id="wings_type" class="form-control input_color py-3">
                                            <option value="">Select type</option>
                                            <option value="Division">Division</option>
                                            <option value="District">District</option>
                                            <option value="Tehsil">Tehsil</option>
                                            <option value="International">Inernational</option>
                                        </select>
                                        <?php $__errorArgs = ['wings_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                                    </div>
                                </div>

                                <div class="mb-6">
                                    <div class="form-group">
                                        <label for="form-label" class="form-label">Wings type name<span
                                                class="text-danger">*</span></label>
                                        <select name="wings_type_name" id="wings_type_name"
                                            class="form-control input_color py-3">
                                            <option value="">Select</option>
                                        </select>
                                        <?php $__errorArgs = ['wings_type_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>
                                </div>

                                <div class="mb-6">
                                    <div class="form-group">
                                        <label for="form-label" class="form-label">Profession name <span
                                                class="text-danger">*</span></label>
                                        <select name="profession_name" id="profession_name"
                                            class="form-control input_color py-3">
                                            <option value="">Select</option>
                                        </select>
                                        <?php $__errorArgs = ['profession_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>


                                <div class="col-md-12">
                                    <div class="mt-3 text-end">
                                        <button type="submit" class="btn btn-primary waves-effect waves-light">Create<i
                                                class="fa-solid fa-circle-plus ms-2"></i></button>
                                    </div>
                                </div>

                            </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        // Handle the first dropdown change event
        $('#wings_type').on('change', function() {
            var selectedType = $(this).val();

            if (selectedType) {
                $.ajax({
                    url: baseUrl + '/get-names',
                    type: 'GET',
                    data: {
                        model: selectedType
                    },
                    success: function(response) {
                        var typeDetailsSelect = $('#wings_type_name');
                        typeDetailsSelect.empty();
                        typeDetailsSelect.append(
                            `<option value="">Select ${selectedType}</option>`);

                        $.each(response, function(index, name) {
                            typeDetailsSelect.append('<option value="' + name +
                                '">' + name + '</option>');
                        });
                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX Error: ' + status + error);
                    }
                });
            } else {
                $('#typeDetails').empty().append('<option value="">Select</option>');
            }
        });

        // Handle the second dropdown change event
        $('#wings_type_name').on('change', function() {
            var selectedValue = $(this).val();
            var selectedType = $('#wings_type').val();

            if (selectedValue && selectedType) {
                $.ajax({
                    url: baseUrl + '/get-professions',
                    type: 'GET',
                    data: {
                        type: selectedType,
                        value: selectedValue
                    },
                    success: function(response) {
                        console.log(response);
                        var professionSelect = $('#profession_name');
                        professionSelect.empty();
                        professionSelect.append(
                            '<option value="">Select Profession</option>');

                        var uniqueProfessions = [...new Set(response)];

                        $.each(uniqueProfessions, function(index, profession) {
                            professionSelect.append('<option value="' + profession +
                                '">' + profession + '</option>');
                        });
                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX Error: ' + status + error);
                    }
                });
            } else {
                $('#profession_name').empty().append('<option value="">Select</option>');
            }
        });
    });
</script>

<?php echo $__env->make('backend.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kamrul\federation\resources\views/backend/page/wings/create.blade.php ENDPATH**/ ?>


<?php $__env->startSection('main-content'); ?>
    <div class="card m-3">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5>Nomini List</h5>
        </div>

        <div class="table-responsive text-nowrap">
            <table class="table">
                <thead>
                    <tr>
                        <th>SL No. </th>
                        <th>Name</th>
                        <th>Vote type</th>
                        <th>Vote position type</th>
                        <th>Charge</th>
                        <th>payment type</th>
                        <th>Endorsment</th>
                        <th>status</th>
                        <th>Action </th>

                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">



                    <?php $__currentLoopData = $allnomini; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $singlevalue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <span class="fw-medium ms-2"><?php echo e($index + 1); ?></span>
                            </td>
                            <td><?php echo e($singlevalue->user->fname); ?></td>
                            <td><?php echo e($singlevalue->votetype); ?></td>
                            <td><?php echo e($singlevalue->votepositiontype); ?></td>
                            <td><?php echo e($singlevalue->charge); ?></td>

                            <td><span><?php echo e($singlevalue->payment_type); ?></span></td>
                            <td> <span><?php echo e((int) $singlevalue->email_one_verified + (int) $singlevalue->email_two_verified); ?></span></td>

                            <td>
                                <?php if($singlevalue->status == 1): ?>
                                    <span class="badge bg-label-danger me-1">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-label-success me-1">Pending</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="dropdown">


                                    <?php if($singlevalue->status == 0): ?>
                                        <form action="<?php echo e(route('nomini.approve', $singlevalue->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('POST'); ?>
                                            <button class="btn btn-primary" type="submit"> <a class=""
                                                    href=""></a><i class="fa fa-check me-2"></i>Approve</button>
                                        </form>
                                    <?php else: ?>
                                        <form action="<?php echo e(route('nomini.declined', $singlevalue->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('POST'); ?>
                                            <button class="btn btn-primary" type="submit"> <a class=""
                                                    href=""></a><i class="fa fa-ban me-2"></i>Declined</button>
                                        </form>
                                    <?php endif; ?>

                                    <a class="btn btn-danger mt-1" href="<?php echo e(route('nomini.delete', $singlevalue->id)); ?>"
                                        onclick="return confirm('Are Your Suere')"><i class="fa fa-trash me-2"></i>
                                        Delete</a>

                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="card m-3">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5>Wings Nomini List</h5>
        </div>

        <div class="table-responsive text-nowrap">
            <table class="table">
                <thead>
                    <tr>
                        <th>SL No. </th>
                        <th>Name</th>
                        <th>Vote type</th>
                        <th>Vote position type</th>
                        <th>Charge</th>
                        <th>payment type</th>
                        <th>Endorsment</th>
                        <th>status</th>
                        <th>Action </th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">



                    <?php $__currentLoopData = $allwingsnomini; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $singlevalue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <span class="fw-medium ms-2"><?php echo e($index + 1); ?></span>
                            </td>
                            <td><?php echo e($singlevalue->user->fname); ?></td>
                            <td><?php echo e($singlevalue->votetype); ?></td>
                            <td><?php echo e($singlevalue->votepositiontype); ?></td>
                            <td><?php echo e($singlevalue->charge); ?></td>

                            <td><span><?php echo e($singlevalue->payment_type); ?></span></td>
                            <td> <span><?php echo e((int) $singlevalue->email_one_verified + (int) $singlevalue->email_two_verified); ?></span></td>

                            <td>
                                <?php if($singlevalue->status == 1): ?>
                                    <span class="badge bg-label-danger me-1">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-label-success me-1">Pending</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="dropdown">


                                    <?php if($singlevalue->status == 0): ?>
                                        <form action="<?php echo e(route('wingsnomini.approve', $singlevalue->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('POST'); ?>
                                            <button class="btn btn-primary" type="submit"> <a class=""
                                                    href=""></a><i class="fa fa-check me-2"></i>Approve</button>
                                        </form>
                                    <?php else: ?>
                                        <form action="<?php echo e(route('wingsnomini.declined', $singlevalue->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('POST'); ?>
                                            <button class="btn btn-primary" type="submit"> <a class=""
                                                    href=""></a><i class="fa fa-ban me-2"></i>Declined</button>
                                        </form>
                                    <?php endif; ?>

                                    <a class="btn btn-danger mt-1" href="<?php echo e(route('wingsnomini.delete', $singlevalue->id)); ?>"
                                        onclick="return confirm('Are Your Suere')"><i class="fa fa-trash me-2"></i>
                                        Delete</a>

                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kamrul\federation\resources\views/frontend/pages/Nomination/allnomin.blade.php ENDPATH**/ ?>
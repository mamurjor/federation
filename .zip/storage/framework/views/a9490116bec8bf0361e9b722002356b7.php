<!doctype html>
<html lang="en">

<head>
    <title><?php echo $__env->yieldContent('title'); ?>- <?php echo e(env('APP_NAME')); ?></title>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- Bootstrap CSS v5.2.1 -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.5.0/css/flag-icon.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css" />
    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/responsive.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/style.css')); ?>">
    <!-- Toastr CSS-->
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <?php echo $__env->yieldPushContent('styles'); ?>
    <style>
        .required::after {
            content: '*';
            color: red;
        }

        .price-range-slider {
            width: 100%;
            padding: 10px 20px;
        }

        .price-range-slider .range-value {
            margin: 0;
        }

        .price-range-slider .range-value input {
            width: 100%;
            background: none;
            color: #000;
            font-size: 16px;
            font-weight: initial;
            box-shadow: none;
            border: none;
            margin: 20px 0 20px 0;
        }

        .price-range-slider .range-bar {
            border: none;
            background: #000;
            height: 3px;
            width: 96%;
            margin-left: 8px;
        }

        .price-range-slider .range-bar .ui-slider-range {
            background: #06b9c0;
        }

        .price-range-slider .range-bar .ui-slider-handle {
            border: none;
            border-radius: 25px;
            background: #fff;
            border: 2px solid #06b9c0;
            height: 17px;
            width: 17px;
            top: -0.52em;
            cursor: pointer;
        }

        .price-range-slider .range-bar .ui-slider-handle+span {
            background: #06b9c0;
        }
    </style>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        // Pass the base URL from Laravel to JavaScript
        var baseUrl = '<?php echo e(url('/')); ?>';
    </script>
    <!-- Include your custom JavaScript file -->

</head>

<body>
    <?php echo $__env->make('frontend.include.Header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- header end -->
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <!-- footer start -->
    <?php echo $__env->make('frontend.include.Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Bootstrap JavaScript Libraries -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"></script>
    <!-- Toastr JS-->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script>
        function flashMessage(status, message) {
            toastr.options = {
                "closeButton": true,
                "debug": false,
                "newestOnTop": false,
                "progressBar": true,
                "positionClass": "toast-top-right",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            }
            switch (status) {
                case 'success':
                    toastr.success(message);
                    break;

                case 'error':
                    toastr.error(message);
                    break;

                case 'info':
                    toastr.info(message);
                    break;

                case 'warning':
                    toastr.warning(message);
                    break;
            }
        }

        // session flash message
        <?php if(Session::get('success')): ?>
            flashMessage('success', "<?php echo e(Session::get('success')); ?>")
        <?php elseif(Session::get('error')): ?>
            flashMessage('error', "<?php echo e(Session::get('error')); ?>")
        <?php elseif(Session::get('info')): ?>
            flashMessage('info', "<?php echo e(Session::get('info')); ?>")
        <?php elseif(Session::get('warning')): ?>
            flashMessage('warning', "<?php echo e(Session::get('warning')); ?>")
        <?php endif; ?>
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html>
<?php /**PATH D:\kamrul\federation\resources\views/layouts/front.blade.php ENDPATH**/ ?>
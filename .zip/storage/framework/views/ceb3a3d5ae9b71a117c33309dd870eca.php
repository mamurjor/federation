<?php $__env->startSection('main-content'); ?>
    <style>
        .apply_form_border {
            border-bottom: 1px solid #ddd;
            padding-bottom: 30px;
        }

        .apply_input_color {
            background: #dddddd40;

            padding: 10px 10px;
            margin-top: 10px
        }
    </style>

    <div class="content-wrapper">
        <!-- Content -->
        <div class="card m-4">
            <div class="card-header d-flex justify-content-between align-items-center border-1 pb-0">
                <h4 class="fw-600"> All Vote</h4>
            </div>
            <div class="p-2 table-responsive text-nowrap">
                <table class="table">
                    <thead class="table-primary table-border-bottom-0">
                        <tr>
                            <th> <input type="checkbox" class="client_checkbx"></th>
                            <th>SL No.</th>
                            <th>Tehsil Name</th>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Vote Type</th>
                            <th>Action </th>

                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php $__currentLoopData = $vote; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $singlevalue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <input type="checkbox" name="checkbox">
                                </td>
                                <td>
                                    <span class="fw-medium ms-2"><?php echo e($index + 1); ?></span>
                                </td>
                                <td><i class="fa-solid fa-location-dot text-primary me-1"></i><?php echo e($singlevalue->tehsil); ?>

                                </td>
                                <td><i class="fa-solid fa-calendar-days text-warning me-1"></i><?php echo e($singlevalue->tehsil); ?>

                                </td>
                                <td><i class="fa-solid fa-clock text-danger me-1"></i><?php echo e($singlevalue->tehsil); ?></td>

                                <td><i class="fa-solid fa-trophy text-success me-1"></i><span
                                        class="badge bg-label-success me-1"> <?php echo e($singlevalue->votetype); ?></span></td>
                                <td>
                                    <div class="dropdown">

                                        
                                        <a href="<?php echo e(route('vote.details')); ?>">
                                            <h4 class="mt-3 btn btn-primary">Vote now</h4>
                                        </a>

                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>


        


        <!-- / Content -->
        <?php echo $__env->make('backend.applymodal.apply', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Footer -->
        <footer class="content-footer footer bg-footer-theme">
            <div class="container-xxl">
                <div
                    class="footer-container d-flex align-items-center justify-content-between py-2 flex-md-row flex-column">
                    <div>
                        ©
                        <script>
                            document.write(new Date().getFullYear());
                        </script>
                        , made with ❤️ by
                        <a href="https://pixinvent.com" target="_blank"
                            class="footer-link text-primary fw-medium">Pixinvent</a>
                    </div>
                    <div class="d-none d-lg-inline-block">
                        <a href="https://themeforest.net/licenses/standard" class="footer-link me-4"
                            target="_blank">License</a>
                        <a href="https://1.envato.market/pixinvent_portfolio" target="_blank" class="footer-link me-4">More
                            Themes</a>

                        <a href="https://demos.pixinvent.com/vuexy-html-admin-template/documentation/" target="_blank"
                            class="footer-link me-4">Documentation</a>

                        <a href="https://pixinvent.ticksy.com/" target="_blank"
                            class="footer-link d-none d-sm-inline-block">Support</a>
                    </div>
                </div>
            </div>
        </footer>
        <!-- / Footer -->

        <div class="content-backdrop fade"></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.client_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kamrul\federation\resources\views/backend/include/content_wrapper.blade.php ENDPATH**/ ?>
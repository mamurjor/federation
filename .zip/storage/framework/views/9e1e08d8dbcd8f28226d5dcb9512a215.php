

<?php $__env->startSection('main-content'); ?>
    <div class="card m-3">
    
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5>Blog Category List</h5>
                <h5><a class="btn btn-primary waves-effect waves-light" href="<?php echo e(route('blogcategories.create')); ?>"> Add New </a>
                </h5>
            </div>


        <div class="table-responsive text-nowrap">
            <table class="table">
                <thead>
                    <tr>
                        <th>SL No. </th>
                        <th>Name</th>
                        <th>Status</th>
                        <th>Action </th>

                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">



                    <?php $__currentLoopData = $blogcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $singlevalue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>

                                <span class="fw-medium ms-2"><?php echo e($index + 1); ?></span>
                            </td>
                            <td><?php echo e($singlevalue->name); ?></td>

                            <td>
                                <?php if( $singlevalue->status == 'active'): ?>
                                  <span class="badge bg-label-success me-1"><?php echo e($singlevalue->status); ?></span>
                                <?php else: ?>
                                <span class="badge bg-label-danger me-1"><?php echo e($singlevalue->status); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="dropdown">
                                    <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                        data-bs-toggle="dropdown">
                                        <i class="ti ti-dots-vertical"></i>
                                    </button>

                                    <a class="btn btn-primary" href="<?php echo e(route('blogcategories.edit', $singlevalue->id)); ?>"><i
                                            class="ti ti-pencil me-2"></i> Edit</a>
                                    <a class="btn btn-danger" href="<?php echo e(route('blogcategories.delete', $singlevalue->id)); ?>"
                                        onclick="return confirm('Are Your Suere')"> Delete</a>

                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    

    

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kamrul\federation\resources\views/frontend/pages/blogcategory/index.blade.php ENDPATH**/ ?>
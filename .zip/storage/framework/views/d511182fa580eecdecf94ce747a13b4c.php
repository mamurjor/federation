<div class="<?php echo e($parantClass ?? ''); ?> form-group">
    <?php if(!empty($alert)): ?><span class="alert-label"><?php echo e($alert); ?></span><?php endif; ?>
    <?php if(!empty($labelName)): ?>
        <label for="<?php echo e($name); ?>"  class="<?php echo e($labelClass ?? ''); ?> <?php echo e($required ?? ''); ?>"><?php echo e($labelName); ?> <?php if(!empty($optionalText)): ?> <span class="label-optional"><?php echo e($optionalText); ?></span> <?php endif; ?></label>
    <?php endif; ?>

    <input type="<?php echo e($type ?? 'text'); ?>" class="form-control form-control <?php echo e($class ?? ''); ?>" id="<?php echo e($name); ?>" name="<?php echo e($name); ?>" placeholder="<?php echo e($placeholder ?? ''); ?>" aria-describedby="<?php echo e($name); ?>" tabindex="1" autofocus="" value="<?php echo e($value ?? ''); ?>" <?php if(!empty($required)): ?> required="" <?php endif; ?> <?php if(!empty($readonly)): ?> readonly="" <?php endif; ?>>

    <?php if(!empty($inputText)): ?><span class="input-optional w-100"><?php echo $inputText; ?></span><?php endif; ?>


    <?php if(!empty($errorName)): ?>
        <?php $__errorArgs = [$errorName];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger error-text"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php endif; ?>
</div>

<?php /**PATH D:\kamrul\federation\resources\views/components/form/textbox.blade.php ENDPATH**/ ?>
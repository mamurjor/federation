
<?php $__env->startSection('main-content'); ?>
    <div class="m-3">
        <h3>Paypal</h3>
        <h3>Stripe</h3>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kamrul\federation\resources\views/frontend/pages/Settings/PaymentSettings/index.blade.php ENDPATH**/ ?>
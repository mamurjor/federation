

<?php $__env->startSection('main-content'); ?>
    <div class="row">
        <div class="col-xl">
            <div class="card m-3">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5>Edit vote announce</h5>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('voteannounce.update')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="mb-6">
                                    <div class="form-group">
                                        <label for="form-label" class="form-label"> Select Country <span
                                                class="text-danger">*</span></label>
                                        <select name="country" id="country" class="form-control input_color py-3">
                                            <option value="<?php echo e($voteannounce->country); ?>" selected>
                                                <?php echo e($voteannounce->country); ?></option>
                                        </select>

                                        <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>
                                </div>
                                <div class="mb-6">
                                    <div class="form-group">
                                        <label for="form-label" class="form-label"> Select District <span
                                                class="text-danger">*</span></label>
                                        <select name="district" id="district" class="form-control input_color py-3">
                                            <option value="<?php echo e($voteannounce->district); ?>" selected>
                                                <?php echo e($voteannounce->district); ?></option>
                                        </select>
                                        <?php $__errorArgs = ['district'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>
                                </div>
                                <div class="mb-6">
                                    <div class="form-group">
                                        <label for="form-label" class="form-label"> Select Tehsil <span
                                                class="text-danger">*</span></label>
                                        <select name="tehsil" id="tehsil" class="form-control input_color py-3">

                                            <option value="<?php echo e($voteannounce->tehsil); ?>"><?php echo e($voteannounce->tehsil); ?></option>
                                        </select>
                                        <?php $__errorArgs = ['tehsil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>
                                </div>
                                <div class="mb-6">
                                    <div class="form-group">
                                        <label for="form-label" class="form-label">Announcement<span
                                                class="text-danger">*</span></label>
                                        <textarea name="announce" class="form-control py-3 input_color" id="" cols="30" rows="10"><?php echo e($voteannounce->announce); ?></textarea>
                                        <?php $__errorArgs = ['announce'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="mb-6">
                                    <div class="form-group">
                                        <label for="form-label" class="form-label"> Select vote type <span
                                                class="text-danger">*</span></label>
                                        <select name="votetype" id="" class="form-control input_color py-3">
                                            <option value="<?php echo e($voteannounce->votetype); ?>" selected>
                                                <?php echo e($voteannounce->votetype); ?></option>
                                        </select>
                                        <?php $__errorArgs = ['votetype'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>
                                </div>

                                <div class="mb-6">
                                    <div class="form-group">
                                        <label for="form-label" class="form-label">Select vote position type <span
                                                class="text-danger">*</span></label>
                                        <select name="votepositiontype[]" id="" multiple data-live-search="true"
                                            class="selectpicker form-control input_color py-3">

                                            <?php $__currentLoopData = $votepositiontype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($data->name); ?>"><?php echo e($data->name); ?> </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                            <?php
                                                $votepositiontype = unserialize($voteannounce->votepositiontype);
                                            ?>

                                            <?php $__currentLoopData = $votepositiontype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($option); ?>" selected>
                                                    <?php echo e($option); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                        <?php $__errorArgs = ['votepositiontype'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>


                                <div class="mb-6">
                                    <div class="form-group">
                                        <label for="form-label" class="form-label">Voting Date<span
                                                class="text-danger">*</span></label>
                                        <input type="date" value="<?php echo e($voteannounce->votingdate); ?>" name="date"
                                            class="form-control py-3 input_color" placeholder="Enter ">
                                        <input type="hidden" value="<?php echo e($voteannounce->id); ?>" name="id"
                                            class="form-control py-3 input_color" placeholder="Enter ">
                                        <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="mb-6">
                                    <div class="form-group">
                                        <label for="form-label" class="form-label">Image<span
                                                class="text-danger">*</span></label>
                                        <img src=" <?php echo url('/') . $voteannounce->image; ?>" alt="tst">

                                        <input type="file" value="" name="voteimage"
                                            class="form-control py-3 input_color" placeholder="Enter ">
                                        <?php $__errorArgs = ['voteimage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>


                                <div class="col-md-12">
                                    <div class="mt-3 text-end">
                                        <button type="submit"
                                            class="btn btn-primary waves-effect waves-light">Update<i
                                                class="fa-solid fa-circle-plus ms-2"></i></button>
                                    </div>
                                </div>

                            </div>
                    </form>
                </div>
            </div>
        </div>

    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            $("#country").change(function() {

                var country = $('#country').val();
                $.ajax({
                    url: '<?php echo e(route('tehsil.getdistrict', ':country')); ?>'.replace(':country',
                        country),
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {

                        // Check if response is not empty


                        // Check if response is not empty
                        if ($.isEmptyObject(response)) {
                            $('#district').empty();
                            var option = "<option value='" + 0 + "'>" + 'no data found' +
                                "</option>";
                            $("#district").append(option);
                            return;
                        }

                        // Clear existing options
                        $('#district').empty();

                        // Append new options
                        $.each(response, function(id, data) {
                            var option = "<option  value='" + data.name + "'>" + data
                                .name + "</option>";
                            $("#district").append(option);
                        });

                    }
                });

            });
            //var value = $('#dropDownId').val();

        });





        $(document).ready(function() {
            $("#district").change(function() {

                var district = $('#district').val();
                $.ajax({
                    url: '<?php echo e(route('tehsil.gettehsil', ':district')); ?>'.replace(':district',
                        district),
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        if ($.isEmptyObject(response)) {
                            $('#tehsil').empty();
                            var option = "<option value='" + 0 + "'>" + 'no data found' +
                                "</option>";
                            $("#tehsil").append(option);
                            return;
                        }

                        // Clear existing options
                        $('#tehsil').empty();

                        // Append new options
                        $.each(response, function(id, data) {
                            var option = "<option  value='" + data.name + "'>" + data
                                .name + "</option>";
                            $("#tehsil").append(option);
                        });

                    }
                });

            });
            //var value = $('#dropDownId').val();

        });
    </script>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kamrul\federation\resources\views/frontend/pages/voteannounce/edit.blade.php ENDPATH**/ ?>


<?php $__env->startSection('main-content'); ?>
    <div class="row">
        <div class="col-xl">
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><a href="<?php echo e(route('votepositiontype.index')); ?>"> List </a></h5>

                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('votepositiontype.update')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="mb-6">
                                    <div class="form-group">
                                        <label for="form-label" class="form-label">Name. <span
                                                class="text-danger">*</span></label>
                                        <input type="hidden" value="<?php echo e($votepositiontype->id); ?>" name="id"
                                            class="form-control py-3 input_color" placeholder="Enter Name">
                                        <input type="text" value="<?php echo e($votepositiontype->name); ?>" name="name"
                                            class="form-control py-3 input_color" placeholder="Enter Name">
                                    </div>
                                </div>
                                <div class="mb-6">
                                    <div class="form-group">
                                        <label for="form-label" class="form-label">Code <span
                                                class="text-danger">*</span></label>
                                        <input type="text" value="<?php echo e($votepositiontype->code); ?>" name="code"
                                            class="form-control py-3 input_color" placeholder="Enter Code">
                                    </div>
                                </div>
                                <div class="mb-6">
                                    <div class="form-group">
                                        <label for="form-label" class="form-label">charge <span
                                                class="text-danger">*</span></label>
                                        <input type="text" value="<?php echo e($votepositiontype->charge); ?>" name="charge"
                                            class="form-control py-3 input_color" placeholder="Enter charge">
                                    </div>
                                </div>


                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <button type="submit" class="py-4 w-100 border-0 resgiter_button rounded">Update<i
                                                class="fa-solid fa-circle-plus ms-2"></i></button>
                                    </div>
                                </div>

                            </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kamrul\federation\resources\views/frontend/pages/votepositiontype/edit.blade.php ENDPATH**/ ?>
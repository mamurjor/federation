

<?php $__env->startSection('main-content'); ?>
   Billing 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kamrul\federation\resources\views/backend/billing/billing.blade.php ENDPATH**/ ?>


<?php $__env->startSection('main-content'); ?>
<div class="card m-3">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5>All Vote</h5>
    </div>

    <div class="table-responsive text-nowrap">
        <table class="table">
            <thead class="table-primary">
                <tr>
                    <th>SL No.</th>
                    <th>Total Vote</th>
                    <th>Nomini Name</th>
                    <th>Vote type</th>
                    <th>Vote position type</th>
                    <th>Tehsil</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody class="table-border-bottom-0">
                <?php $__currentLoopData = $voteclick; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $singlevalue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <span class="fw-medium ms-2"><?php echo e($index + 1); ?></span>
                        </td>
                        <td><?php echo e($singlevalue->vote_count); ?></td>
                        <td><?php echo e($singlevalue->fname); ?></td>
                        <td><?php echo e($singlevalue->votetype); ?></td>
                        <td><?php echo e($singlevalue->votepositiontype); ?></td>
                        <td><?php echo e($singlevalue->tehsil); ?></td>
                        <td><?php echo e($singlevalue->status); ?></td>
                        
                        <td>
                            <?php if($singlevalue->status == 0 && !$hasSelectedNomini): ?>
                                <form action="<?php echo e(route('nomini.select', $singlevalue->nomini_id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-primary" type="submit"><i class="fa fa-check me-2"></i>Select</button>
                                </form>
                            <?php elseif($singlevalue->status == 1): ?>
                                <button class="btn btn-success" type="button"><i class="fa fa-check me-2"></i>Selected</button>
                            <?php else: ?>
                                <button class="btn btn-secondary" type="button" onclick="alert('You are already selected one Nomini')">
                                    <i class="fa fa-check me-2"></i>Select
                                </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<div class="card m-3">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5>All Wings Vote</h5>
    </div>

    <div class="table-responsive text-nowrap">
        <table class="table">
            <thead class="table-success">
                <tr>
                    <th>SL No.</th>
                    <th>Total Vote</th>
                    <th>Nomini Name</th>
                    <th>Vote type</th>
                    <th>Vote position type</th>
                    <th>Profession</th>
                    <th>status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody class="table-border-bottom-0">
                <?php $__currentLoopData = $wingsvoteclick; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $singlevalue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <span class="fw-medium ms-2"><?php echo e($index + 1); ?></span>
                        </td>
                        <td><?php echo e($singlevalue->vote_count); ?></td>
                        <td><?php echo e($singlevalue->fname); ?></td>
                        <td><?php echo e($singlevalue->votetype); ?></td>
                        <td><?php echo e($singlevalue->votepositiontype); ?></td>
                        <td><?php echo e($singlevalue->profession_name); ?></td>
                        <td><?php echo e($singlevalue->status); ?></td>
                        <td>
                            <?php if($singlevalue->status == 0 && !$hasSelectedWingsNomini): ?>
                                <form action="<?php echo e(route('wingsnomini.select', $singlevalue->Wingsnomini_id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-primary" type="submit"><i class="fa fa-check me-2"></i>Select</button>
                                </form>
                            <?php elseif($singlevalue->status == 1): ?>
                                <button class="btn btn-success" type="button"><i class="fa fa-check me-2"></i>Selected</button>
                            <?php else: ?>
                                <button class="btn btn-secondary" type="button" onclick="alert('You are already selected one Nomini')">
                                    <i class="fa fa-check me-2"></i>Select
                                </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kamrul\federation\resources\views/frontend/pages/voteclick/index.blade.php ENDPATH**/ ?>
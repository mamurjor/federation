

<?php $__env->startSection('main-content'); ?>
    <div class="card m-3">

        <div class="card-header d-flex justify-content-between align-items-center">
            <h5>All Vote</h5>
            </h5>
        </div>


        <div class="table-responsive text-nowrap">
            <table class="table">
                <thead class="">
                    <tr>
                        <th>SL No. </th>
                        <th>Total Vote</th>
                        <th>Nomini Name</th>
                        <th>Vote type </th>
                        <th>Vote position type </th>
                        <th>Tehsil </th>

                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    <?php $__currentLoopData = $voteclick; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $singlevalue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <span class="fw-medium ms-2"><?php echo e($index + 1); ?></span>
                            </td>
                            <td><?php echo e($singlevalue->vote_count); ?></td>
                            <td><?php echo e($singlevalue->fname); ?></td>
                            <td><?php echo e($singlevalue->votetype); ?></td>
                            <td><?php echo e($singlevalue->votepositiontype); ?></td>
                            <td><?php echo e($singlevalue->tehsil); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kamrul\federation\resources\views/frontend/pages/voteclick/index.blade.php ENDPATH**/ ?>
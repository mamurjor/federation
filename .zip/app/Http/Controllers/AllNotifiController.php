<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class AllNotifiController extends Controller
{
  

    // public function viewAll(){
    //     dd("test");
    // }
}
